<!doctype html>
<?php
include( "functions.php" );
 
$obj =  new Functions();
?>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="css/reset.css"> <!-- CSS reset -->
	<link rel="stylesheet" href="css/style.css"> <!-- Resource style -->
	<script src="js/modernizr.js"></script> <!-- Modernizr -->
  <script src="js/table-sort.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="dist/style.css">
  	
	<title>Search Results</title>
</head>
<body>
	<header class="cd-main-header animate-search">
		<div class="cd-logo"><a href="index.php"><img src="img/cd-logo.svg" alt="Logo"></a></div>

		<nav class="cd-main-nav-wrapper">
			<a href="#search" class="cd-search-trigger cd-text-replace">Search</a>
			
			<ul class="cd-main-nav">
				<li><a href="#0">Products</a></li>
				<li><a href="#0">Store</a></li>
				<li><a href="#0">Blog</a></li>
				<li><a href="#0">Contact</a></li>
			</ul> <!-- .cd-main-nav -->
		</nav> <!-- .cd-main-nav-wrapper -->

		<a href="#0" class="cd-nav-trigger cd-text-replace">Menu<span></span></a>
	</header>
  <main class="cd-main-content">
    <!-- your content here -->
    <div class="content-center">
      <h1>Search Results</h1>
			<?php
if($_POST['All']=='camera')
{
  if (isset($_POST['txtsearch']))
  {
    $search = $_POST['txtsearch'];
    $camera = $obj->txtget_camera($search);
  }

  else
  {
    $camera = $obj->get_camera();
  }
  
?>
      <table class="table-sort table-arrows remember-sort">
      <thead>
  <tr>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Brand</th>
    <th>Original Price</th>
    <th>Retail Price</th>
    <th>Currency</th>
    <th>Category</th>
    <th>Date added</th>
    <th>Date updated</th>
  </tr>
</thead>
<tbody>
    <?php

    while( $row = sparql_fetch_array( $camera ) )
    {
    ?>        
  <tr>

    <td>   
          <?php echo $row["ProductID"]; ?></p>
          </td>
    <td>   
          <?php echo $row["ProductName"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Brand"]; ?></p>
            </td>
    <td>         
          <?php echo $row["Original_Price"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Retail_Price"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Currency"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Category"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_added"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_updated"]; ?></p>
            <?php } ?></td>
  </tr>
  </tbody>
</table>

<?php
}
else if($_POST['All']=='all')
{
  if (isset($_POST['txtsearch']))
  {
    $search = $_POST['txtsearch'];
    $all = $obj->txtget_all($search);
    
  }

  else
  {
    $all = $obj->get_all();
  }
?>
      <table class="table-sort table-arrows remember-sort">
    <thead>
  <tr>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Brand</th>
    <th>Original Price</th>
    <th>Retail Price</th>
    <th>Currency</th>
    <th>Category</th>
    <th>Date added</th>
    <th>Date updated</th>
  </tr>
</thead>
<tbody>
    <?php

    while( $row = sparql_fetch_array( $all ) )
    {
    ?>        
  <tr>

    <td>   
          <?php echo $row["ProductID"]; ?></p>
          </td>
    <td>   
          <?php echo $row["ProductName"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Brand"]; ?></p>
            </td>
    <td>         
          <?php echo $row["Original_Price"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Retail_Price"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Currency"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Category"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_added"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_updated"]; ?></p>
            <?php } ?></td>
  </tr>
  </tbody>
</table>

<?php
}
else if($_POST['All']=='computer')
{
  if (isset($_POST['txtsearch']))
  {
    $search = $_POST['txtsearch'];
    $computer = $obj->txtget_computer($search);
  }
  else
  {
    $computer = $obj->get_computer();
  }
  
?>
      <table class="table-sort table-arrows remember-sort">
      <thead>
  <tr>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Brand</th>
    <th>Original Price</th>
    <th>Retail Price</th>
    <th>Currency</th>
    <th>Category</th>
    <th>Date added</th>
    <th>Date updated</th>
  </tr>
  </thead>
  <tbody>

    <?php

    while( $row = sparql_fetch_array( $computer ) )
    {
    ?>        
  <tr>

    <td>   
          <?php echo $row["ProductID"]; ?></p>
          </td>
    <td>   
          <?php echo $row["ProductName"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Brand"]; ?></p>
            </td>
    <td>         
          <?php echo $row["Original_Price"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Retail_Price"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Currency"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Category"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_added"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_updated"]; ?></p>
            <?php } ?></td>
  </tr>
  </tbody>
</table>

<?php
}
else if($_POST['All']=='laptop')
{
  if (isset($_POST['txtsearch']))
  {
    $search = $_POST['txtsearch'];
    $laptop = $obj->txtget_laptop($search);
  }
  else
  {
    $laptop = $obj->get_laptop();
  }
?>
      <table class="table-sort table-arrows remember-sort">
      <thead>
  <tr>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Brand</th>
    <th>Original Price</th>
    <th>Retail Price</th>
    <th>Currency</th>
    <th>Category</th>
    <th>Date added</th>
    <th>Date updated</th>
  </tr>
  </thead>
  <tbody>
    <?php

    while( $row = sparql_fetch_array( $laptop ) )
    {
    ?>        
  <tr>

    <td>   
          <?php echo $row["ProductID"]; ?></p>
          </td>
    <td>   
          <?php echo $row["ProductName"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Brand"]; ?></p>
            </td>
    <td>         
          <?php echo $row["Original_Price"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Retail_Price"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Currency"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Category"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_added"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_updated"]; ?></p>
            <?php } ?></td>
  </tr>
  </tbody>
</table>

<?php
}
else if($_POST['All']=='phone')
{
  if (isset($_POST['txtsearch']))
  {
    $search = $_POST['txtsearch'];
    $phone = $obj->txtget_phone($search);
  }
  else
  {
    $phone = $obj->get_phone();
  }
?>
      <table class="table-sort table-arrows remember-sort">
      <thead>
  <tr>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Brand</th>
    <th>Original Price</th>
    <th>Retail Price</th>
    <th>Currency</th>
    <th>Category</th>
    <th>Date added</th>
    <th>Date updated</th>
  </tr>
  </thead>
  <tbody>
    <?php

    while( $row = sparql_fetch_array( $phone ) )
    {
    ?>        
  <tr>

    <td>   
          <?php echo $row["ProductID"]; ?></p>
          </td>
    <td>   
          <?php echo $row["ProductName"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Brand"]; ?></p>
            </td>
    <td>         
          <?php echo $row["Original_Price"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Retail_Price"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Currency"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Category"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_added"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_updated"]; ?></p>
            <?php } ?></td>
  </tr>
  </tbody>
</table>

<?php
}
else if($_POST['All']=='router')
{
  if (isset($_POST['txtsearch']))
  {
    $search = $_POST['txtsearch'];
    $router = $obj->txtget_router($search);
  }
  else
  {
    $router = $obj->get_router();
  }
?>
      <table class="table-sort table-arrows remember-sort">
      <thead>
  <tr>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Brand</th>
    <th>Original Price</th>
    <th>Retail Price</th>
    <th>Currency</th>
    <th>Category</th>
    <th>Date added</th>
    <th>Date updated</th>
  </tr>
  </thead>
  <tbody>
    <?php

    while( $row = sparql_fetch_array( $router ) )
    {
    ?>        
  <tr>

    <td>   
          <?php echo $row["ProductID"]; ?></p>
          </td>
    <td>   
          <?php echo $row["ProductName"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Brand"]; ?></p>
            </td>
    <td>         
          <?php echo $row["Original_Price"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Retail_Price"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Currency"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Category"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_added"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_updated"]; ?></p>
            <?php } ?></td>
  </tr>
  </tbody>
</table>

<?php
}
else if($_POST['All']=='tablet')
{
  if (isset($_POST['txtsearch']))
  {
    $search = $_POST['txtsearch'];
    $tablet = $obj->txtget_tablet($search);
  }
  else
  {
    $tablet = $obj->get_tablet();
  }
?>
      <table class="table-sort table-arrows remember-sort">
      <thead>
  <tr>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Brand</th>
    <th>Original Price</th>
    <th>Retail Price</th>
    <th>Currency</th>
    <th>Category</th>
    <th>Date added</th>
    <th>Date updated</th>
  </tr>
  </thead>
  <tbody>
    <?php

    while( $row = sparql_fetch_array( $tablet ) )
    {
    ?>        
  <tr>

    <td>   
          <?php echo $row["ProductID"]; ?></p>
          </td>
    <td>   
          <?php echo $row["ProductName"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Brand"]; ?></p>
            </td>
    <td>         
          <?php echo $row["Original_Price"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Retail_Price"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Currency"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Category"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_added"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_updated"]; ?></p>
            <?php } ?></td>
  </tr>
  </tbody>
</table>

<?php
}
else if($_POST['All']=='TV')
{
  if (isset($_POST['txtsearch']))
  {
    $search = $_POST['txtsearch'];
    $tv = $obj->txtget_tv($search);
  }
  else
  {
    $tv = $obj->get_tv();
  }
?>
      <table class="table-sort table-arrows remember-sort">
      <thead>
  <tr>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Brand</th>
    <th>Original Price</th>
    <th>Retail Price</th>
    <th>Currency</th>
    <th>Category</th>
    <th>Date added</th>
    <th>Date updated</th>
  </tr>
  </thead>
  <tbody>
    <?php

    while( $row = sparql_fetch_array( $tv ) )
    {
    ?>        
  <tr>

    <td>   
          <?php echo $row["ProductID"]; ?></p>
          </td>
    <td>   
          <?php echo $row["ProductName"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Brand"]; ?></p>
            </td>
    <td>         
          <?php echo $row["Original_Price"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Retail_Price"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Currency"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Category"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_added"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_updated"]; ?></p>
            <?php } ?></td>
  </tr>
  </tbody>
</table>

<?php
}
else if($_POST['All']=='men')
{
  if (isset($_POST['txtsearch']))
  {
    $search = $_POST['txtsearch'];
    $men = $obj->txtget_men($search);
  }
  else
  {
    $men = $obj->get_men();
  }
?>
      <table class="table-sort table-arrows remember-sort">
      <thead>
  <tr>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Brand</th>
    <th>Original Price</th>
    <th>Retail Price</th>
    <th>Currency</th>
    <th>Category</th>
    <th>Date added</th>
  </tr>
  </thead>
  <tbody>
    <?php

    while( $row = sparql_fetch_array( $men ) )
    {
    ?>        
  <tr>

    <td>   
          <?php echo $row["ProductID"]; ?></p>
          </td>
    <td>   
          <?php echo $row["ProductName"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Brand"]; ?></p>
            </td>
    <td>         
          <?php echo $row["Original_Price"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Retail_Price"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Currency"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Category"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_added"]; ?></p>
            </td>
            <?php } ?>
  </tr>
  </tbody>
</table>

<?php
}
else if($_POST['All']=='women')
{
  if (isset($_POST['txtsearch']))
  {
    $search = $_POST['txtsearch'];
    $women = $obj->txtget_women($search);
  }
  else
  {
    $women = $obj->get_women();
  }
?>
      <table class="table-sort table-arrows remember-sort">
      <thead>
  <tr>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Brand</th>
    <th>Original Price</th>
    <th>Retail Price</th>
    <th>Currency</th>
    <th>Category</th>
    <th>Date added</th>
  </tr>
  </thead>
  <tbody>
    <?php

    while( $row = sparql_fetch_array( $women ) )
    {
    ?>        
  <tr>

    <td>   
          <?php echo $row["ProductID"]; ?></p>
          </td>
    <td>   
          <?php echo $row["ProductName"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Brand"]; ?></p>
            </td>
    <td>         
          <?php echo $row["Original_Price"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Retail_Price"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Currency"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Category"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Date_added"]; ?></p>
            </td>
            <?php } ?>
  </tr>
  </tbody>
</table>

<?php
}
else if($_POST['All']=='groceries')
{
  if (isset($_POST['txtsearch']))
  {
    $search = $_POST['txtsearch'];
    $groceries = $obj->txtget_groceries($search);
  }
  else
  {
    $groceries = $obj->get_groceries();
  }
?>
      <table class="table-sort table-arrows remember-sort">
      <thead>
  <tr>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Original Price</th>
    <th>Retail Price</th>
    <th>Currency</th>
    <th>Expire Date</th>
  </tr>
  </thead>
  <tbody>
    <?php

    while( $row = sparql_fetch_array( $groceries ) )
    {
    ?>        
  <tr>

    <td>   
          <?php echo $row["ProductID"]; ?></p>
          </td>
    <td>   
          <?php echo $row["ProductName"]; ?></p>
            </td>
    <td>         
          <?php echo $row["Original_Price"]; ?></p>
            </td>
    <td>     
          <?php echo $row["Retail_Price"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Currency"]; ?></p>
            </td>
    <td>       
          <?php echo $row["Expire_Date"]; ?></p>
            </td>
            <?php } ?>
  </tr>
  </tbody>
</table>

<?php
}
else
{
  echo "<script>window.alert('Something wrong!')
  window.location='index.php'</script>";

}
?>

</div>
  </main>
		

	<div id="search" class="cd-main-search">
		<form method="post" action="ecommerce.php">
			<input type="search" name="txtsearch" placeholder="Search...">

			<div class="cd-select">
				<span>in</span>
				<select name="All">
          <option name = "all" value="all">All Electronics</option>
          <option disabled="">---------------------------</option>
					<option value="Electronic Devices" disabled="" style="font-weight: bold; font-size:20">Electronic Devices</option>
					<option value="camera">Cameras</option>
					<option value="computer">Computer</option>
					<option value="laptop">Laptop</option>
					<option value="phone">Phone</option>
					<option value="router">Router</option>
					<option value="tablet">Tablet</option>
					<option value="TV">TV</option>
					<option disabled="">---------------------------</option>
					<option value="Clothes" disabled= "" style="font-weight: bold; font-size:20">Clothes</option>
					<option value="men">Men</option>
					<option value="women">Women</option>
					<option disabled="">---------------------------</option>
					<option value="Others" disabled= "" style="font-weight: bold; font-size:20">Others</option>
					<option value="groceries">Groceries</option>
				</select>
				<span class="selected-value">All Electronics</span>
			</div>
		</form>

		<a href="#0" class="close cd-text-replace"></a>
	</div> <!-- .cd-main-search -->

	<div class="cd-cover-layer"></div> <!-- cover main content when search form is open -->
<script src="js/jquery-2.1.4.js"></script>
<script src="js/main.js"></script> <!-- Resource jQuery -->
 <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script><script  src="./script.js"></script>
</body>
</html>