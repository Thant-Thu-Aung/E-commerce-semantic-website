<?php
require_once( "sparql_library.php" );

class Functions{
    private $db;
    
    public function __construct(){
	$db = sparql_connect( "http://localhost:3030/E-commerce/sparql" );
	if( !$db ) { print sparql_errno() . ": ---" . sparql_error(). "\n"; exit; }
	sparql_ns( "ec","http://www.semanticweb.org/ontologies/E-commerce#" );
    }

    public function get_all(){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function get_camera(){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER regex(?Category, 'Camera') 
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function get_computer(){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER regex(?Category, 'Computer') 
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function get_laptop(){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER regex(?Category, 'Laptop') 
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function get_phone(){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER regex(?Category, 'Phone') 
}

LIMIT 1000";
        $result = sparql_query( $sparql ); 
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        }
        return $result;
    }

    public function get_router(){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER regex(?Category, 'Router') 
}

LIMIT 1000";
        $result = sparql_query( $sparql ); 
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        }
        return $result;
    }

    public function get_tablet(){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER regex(?Category, 'Tablet') 
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function get_tv(){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER regex(?Category, 'TV') 
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function get_men(){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER regex(?Category, '^MEN$') 
}
LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function get_women(){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER regex(?Category, '^WOMEN$') 
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function get_groceries(){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Expire_Date
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Expire_Date ?Expire_Date.
}
LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function txtget_all($search){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
    FILTER (regex(?ProductName, '".$search."', 'i'))
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function txtget_camera($search){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER (regex(?Category, 'Camera') && regex(?ProductName, '".$search."', 'i'))
}

LIMIT 1000";
        $result = sparql_query( $sparql );
        $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        }
        return $result;
    }

    public function txtget_computer($search){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER (regex(?Category, 'Computer') && regex(?ProductName, '".$search."', 'i'))
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function txtget_laptop($search){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER (regex(?Category, 'Laptop') && regex(?ProductName, '".$search."', 'i'))
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function txtget_phone($search){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER (regex(?Category, 'Phone') && regex(?ProductName, '".$search."', 'i'))
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function txtget_router($search){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER (regex(?Category, 'Router') && regex(?ProductName, '".$search."', 'i'))
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function txtget_tablet($search){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER (regex(?Category, 'Tablet') && regex(?ProductName, '".$search."', 'i'))
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function txtget_tv($search){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
    ?product ec:Date_updated ?Date_updated.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER (regex(?Category, 'TV') && regex(?ProductName, '".$search."', 'i'))
}

LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function txtget_men($search){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER (regex(?Category, '^MEN$')&& regex(?ProductName, '".$search."', 'i')) 
}
LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }

    public function txtget_women($search){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Brand ?Category ?Date_added ?Date_updated
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Brand ?Brand.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Date_added ?Date_added.
  
    ?product ec:has_Category ?category.
    ?category ec:Name ?Category.
  FILTER (regex(?Category, '^WOMEN$')&& regex(?ProductName, '".$search."', 'i')) 
}
LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }
    
    public function txtget_groceries($search){
        $sparql = "SELECT DISTINCT ?ProductID ?ProductName ?Original_Price ?Retail_Price ?Currency ?Expire_Date
WHERE 
{
    ?product a ec:Product.
    ?product ec:ID ?ProductID.
    ?product ec:Name ?ProductName.
    ?product ec:Original_Price ?Original_Price.
    ?product ec:Retail_Price ?Retail_Price.
    ?product ec:Currency ?Currency.
    ?product ec:Expire_Date ?Expire_Date.
  FILTER (regex(?ProductName, '".$search."', 'i')) 
}
LIMIT 1000";
        $result = sparql_query( $sparql );
         $count = sparql_num_rows( $result );
        if($count===0)
        {
            echo "<script>window.alert('No Results!')
            window.location='index.php'</script>";
        } 
        return $result;
    }
}
?>