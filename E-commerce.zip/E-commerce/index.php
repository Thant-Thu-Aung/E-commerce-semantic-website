<!doctype html>
<?php
include( "functions.php" );
?>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="css/reset.css"> <!-- CSS reset -->
	<link rel="stylesheet" href="css/style.css"> <!-- Resource style -->
	<script src="js/modernizr.js"></script> <!-- Modernizr -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="dist/style.css">
  	
	<title>E-commerce</title>
</head>
<body>
	<header class="cd-main-header animate-search">
		<div class="cd-logo"><a href="index.php"><img src="img/cd-logo.svg" alt="Logo"></a></div>

		<nav class="cd-main-nav-wrapper">
			<a href="#search" class="cd-search-trigger cd-text-replace" type="submit">Search</a>
			
			<ul class="cd-main-nav">
				<li><a href="#0">Products</a></li>
				<li><a href="#0">Store</a></li>
				<li><a href="#0">Blog</a></li>
				<li><a href="#0">Contact</a></li>
			</ul> <!-- .cd-main-nav -->
		</nav> <!-- .cd-main-nav-wrapper -->

		<a href="#0" class="cd-nav-trigger cd-text-replace">Menu<span></span></a>
	</header>
	
	<main class="cd-main-content">
		<!-- your content here -->
		<div class="content-center">
			<h1>E-commerce Semantic</h1>
			<h1>Advanced Search Form</h1>
		</div>
	</main>

	<div id="search" class="cd-main-search">
		<form method="post" action="ecommerce.php">
			<input type="search" name="txtsearch" placeholder="Search...">

			<div class="cd-select">
				<span>in</span>
				<select data-trigger="" name="All">
					<option name = "all" value="all">All Electronics</option>
					<option disabled="">---------------------------</option>
					<option value="Electronic Devices" disabled="" style="font-weight: bold; font-size:20">Electronic Devices</option>
					<option name = "camera" value="camera">Cameras</option>
					<option value="computer">Computer</option>
					<option value="laptop">Laptop</option>
					<option value="phone">Phone</option>
					<option value="router">Router</option>
					<option value="tablet">Tablet</option>
					<option value="TV">TV</option>
					<option disabled="">---------------------------</option>
					<option value="Clothes" disabled= "" style="font-weight: bold; font-size:20">Clothes</option>
					<option value="men">Men</option>
					<option value="women">Women</option>
					<option disabled="">---------------------------</option>
					<option value="Others" disabled= "" style="font-weight: bold; font-size:20">Others</option>
					<option value="groceries">Groceries</option>
				</select>
				<span class="selected-value">All Electronics</span>
			</div>
		</form>

		<a href="#0" class="close cd-text-replace"></a>
	</div> <!-- .cd-main-search -->

	<div class="cd-cover-layer"></div> <!-- cover main content when search form is open -->
<script src="js/jquery-2.1.4.js"></script>
<script src="js/main.js"></script> <!-- Resource jQuery -->
 <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script><script  src="./script.js"></script>
</body>
</html>